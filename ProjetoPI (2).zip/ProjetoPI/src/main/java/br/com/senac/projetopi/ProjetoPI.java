/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.senac.projetopi;

/**
 *
 * @author vf983
 */
public class ProjetoPI {

    public static void main(String[] args) {
        TelaPrincipal frame = new TelaPrincipal();
        frame.setVisible(true);
    }
}
